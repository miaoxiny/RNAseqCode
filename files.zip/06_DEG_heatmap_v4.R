## ============================================================================
## acute Netrin-1 RNA-seq  ·  06_DEG_heatmap_v2.R   (Phase 4 · DEG 热图)
## ----------------------------------------------------------------------------
## 完全效仿 24h 模板 04_heatmap_66_DEGs：
##   - 行按 5v0 方向分两块 Upregulated(14)/Downregulated(18)，块内各自聚类
##   - 列聚类开（顶部树状图）
##   - 色阶蓝白红，z-score 截断 ±2
##   - 图例 Replicate "Replicate 1/2/3"、Condition 全名
##   - 行标签：有 symbol 用 symbol，无 symbol 用完整 Ensembl 号
##   - 标题 "Batch-corrected expression of N DEGs (visualization only)"
## 数值 = 批校正后 VST 的 z-score（仅可视化，DE 用 raw counts）。
## 读现成对象，先 draw 预览后存。
## ============================================================================
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"
obj_dir  <- file.path(out_base, "results/objects")
fig_dir  <- file.path(out_base, "results/03_DEG")

suppressPackageStartupMessages({
  library(DESeq2); library(ComplexHeatmap); library(circlize); library(limma)
})

vsd     <- readRDS(file.path(obj_dir, "vsd.rds"))
samples <- readRDS(file.path(obj_dir, "sample_sheet.rds"))
degs    <- readRDS(file.path(obj_dir, "deg_tables.rds"))

## ---- 1. 5v0 RELAXED 32，按方向分组 ------------------------------------------
df5 <- degs$df_5v0
rel <- df5[!is.na(df5$padj) & df5$padj < 0.05, ]
rel$direction <- ifelse(rel$log2FoldChange > 0, "Upregulated", "Downregulated")
rel <- rel[order(rel$direction, rel$padj), ]
deg_ens <- rel$ensembl
cat(sprintf("5v0 RELAXED = %d  (up=%d, down=%d)\n", nrow(rel),
            sum(rel$direction=="Upregulated"), sum(rel$direction=="Downregulated")))

row_lab <- ifelse(!is.na(rel$symbol) & rel$symbol!="", rel$symbol, rel$ensembl)

## ---- 2. 批校正后 VST（仅可视化）---------------------------------------------
vmat <- assay(vsd)
des  <- model.matrix(~ samples[colnames(vmat), "timepoint"])
vmat_bc <- limma::removeBatchEffect(vmat,
              batch = samples[colnames(vmat), "replicate"], design = des)

mat  <- vmat_bc[deg_ens, , drop=FALSE]
matz <- t(scale(t(mat)))
rownames(matz) <- row_lab

## v3：列固定顺序 Vehicle->5->15，组内按 replicate
ord <- order(factor(samples[colnames(matz),"timepoint"], levels=c("0","5","15")),
             samples[colnames(matz),"replicate"])
matz <- matz[, ord]
sm <- samples[colnames(matz), ]
colnames(matz) <- sm$label

row_split <- factor(rel$direction, levels=c("Upregulated","Downregulated"))

## ---- 3. 注释条（图例用全名）------------------------------------------------
rep_anno_col <- c(rep1="#E8E8E8", rep2="#B8B8B8", rep3="#888888")
cond_col     <- setNames(c("#E1EAD7","#6B9A5C","#264020"),
                         c("Vehicle","5min Netrin-1","15min Netrin-1"))
rep_for_legend <- factor(sm$replicate, levels=c("rep1","rep2","rep3"),
                         labels=c("Replicate 1","Replicate 2","Replicate 3"))
rep_col2 <- setNames(unname(rep_anno_col), c("Replicate 1","Replicate 2","Replicate 3"))

ha <- HeatmapAnnotation(
  Replicate = rep_for_legend,
  Condition = sm$condition_label,
  col = list(Replicate = rep_col2, Condition = cond_col),
  annotation_name_side = "left",
  annotation_name_gp   = gpar(fontsize = 9),
  simple_anno_size     = unit(6, "mm"),
  border               = TRUE
)

## ---- 4. 色阶蓝白红，z-score 截断 ±2 ----------------------------------------
col_fun <- circlize::colorRamp2(c(-2, -1, 0, 1, 2),
                                c("#3B7AB8","#A8C6E2","#F7F7F7","#E9A6A6","#C73E3E"))

hm <- Heatmap(
  matz, name = "Z-score", col = col_fun, top_annotation = ha,
  row_split = row_split, row_gap = unit(3, "mm"),
  row_title_rot = 90, row_title_gp = gpar(fontsize = 11, fontface="bold"),
  show_row_names = TRUE, show_column_names = FALSE,
  row_names_gp = gpar(fontsize = 7), column_names_gp = gpar(fontsize = 9),
  cluster_rows = TRUE, cluster_columns = FALSE,
  cluster_row_slices = FALSE,
  rect_gp = gpar(col = "white", lwd = 0.4), border = TRUE,
  column_title = sprintf("Batch-corrected expression of %d DEGs (visualization only)", nrow(rel)),
  column_title_gp = gpar(fontsize = 13, fontface = "bold"),
  heatmap_legend_param = list(title_gp = gpar(fontsize = 10),
                              labels_gp = gpar(fontsize = 9),
                              legend_height = unit(3, "cm"))
)

draw(hm)
## —— 满意后存 ——
pdf(file.path(fig_dir,"06_DEG_heatmap_5v0_v4.pdf"), width=8, height=8.5)
draw(hm); dev.off()
png(file.path(fig_dir,"06_DEG_heatmap_5v0_v4.png"), width=8, height=8.5, units="in", res=300)
draw(hm); dev.off()
cat("[fig] 06_DEG_heatmap_5v0_v4 saved\n")
cat("note: batch correction for visualization only; DE testing uses raw counts.\n")
