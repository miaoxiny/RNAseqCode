# Acute Netrin-1 RNA-seq — 分析存档 (README)

E18 大鼠皮层混合原代培养 · 急性 Netrin-1 时间课程 · DRAGEN-Salmon 基因水平定量
R 4.6.0 · 分析完成 Phase 0–7

---

## 1. 实验设计

- **样本**：9 个 = 3 时间点 × 3 生物学重复（每重复每时间点 = 独立孔）
- **条件**：
  - `Vehicle` = PBS vehicle, 5 min（对照）
  - `5min Netrin-1` = Netrin-1 in PBS, 5 min
  - `15min Netrin-1` = Netrin-1, 15 min
  - 注：同一 PBS-5min 对照同时服务 5min 与 15min（无独立 PBS-15min 对照）
- **对比语义**：
  - `5v0`（5min vs Vehicle）= 干净的 Netrin 效应（主结果）
  - `15v5`（15min vs 5min）= 干净的时间演变
  - `15v0`（15min vs Vehicle）= 时长混杂（谨慎解读）

### 样本映射（prefix = [rep][timepoint]）
| sample | prefix | rep | timepoint |
|---|---|---|---|
| R1_T0 | 10MIN_..._D02 | 1 | Vehicle |
| R1_T5 | 15MIN_..._E02 | 1 | 5min |
| R1_T15 | 115MIN_..._F02 | 1 | 15min |
| R2_T0 | 20MIN_..._B03 | 2 | Vehicle |
| R2_T5 | 25MIN_..._C03 | 2 | 5min |
| R2_T15 | 215MIN_..._D03 | 2 | 15min |
| R3_T0 | 30MIN_..._H03 | 3 | Vehicle |
| R3_T5 | 35MIN_..._A04 | 3 | 5min |
| R3_T15 | 315MIN_..._B04 | 3 | 15min |

---

## 2. 目录结构

```
Time analysis/
├── scripts/                    分析脚本（按运行顺序）
├── results/
│   ├── 01_QC/                  文库大小/检出基因/相关热图/PCA
│   ├── 02_composition/         细胞组成 marker 图
│   ├── 03_DEG/                 DEG 表/火山/轨迹/热图/LRT
│   ├── 04_GSEA/                GSEA GO BP+KEGG 结果与图
│   ├── 06_integration/         整合主结果表
│   └── objects/                所有中间 .rds 对象 + 注释 + sessionInfo
输入（外部）: RNA seq acute/  9 个 *.quant.genes.sf
```

---

## 3. 运行顺序与脚本

| 顺序 | 脚本 | Phase | 产出 |
|---|---|---|---|
| 1 | `01_import_qc_v8.R` | 0+1 | dds_filtered/fitted、vsd、sample_sheet、gene_annotation、QC 图、相关热图、PCA-before |
| 2 | `01b_pca_after_v2.R` | 1 | PCA-after（批校正可视化） |
| 3 | `00_export_tpm.R` | 2 前置 | tpm_matrix_raw.rds（32623 全基因，Phase 2 用） |
| 4 | `07_celltype_composition.R` | 2 | 细胞组成 marker 图（22 marker×7 类） |
| 5 | `03_deg_v2.R` | 3 | res_all、deg_tables、dds_lrt、DEG CSV（5v0/15v0/15v5/LRT） |
| 6 | `11_lrt_analysis.R` | 3 补 | DEG_LRT_19_annotated.csv |
| 7 | `04_volcano_v6.R` | 4 | 火山图 5v0 |
| 8 | `05_trajectory.R` | 4 | 6 基因时序轨迹 |
| 9 | `05b_rock_trajectory.R` | 4 | ROCK1 vs ROCK2 轨迹 |
| 10 | `06_DEG_heatmap_v4.R` | 4 | DEG 热图（5v0 32 基因，列固定） |
| 11 | `08_gsea_5v0.R` | 5 | GSEA 5v0 GO BP+KEGG+simplified |
| 12 | `09_gsea_timecourse.R` | 5 | GSEA 15v5+15v0 |
| 13 | `10_gsea_plots.R` | 5 | 所有 GSEA barplot + 镜像散点 |
| 14 | `Phase6_master_table.R` | 6 | 主结果汇总表 |

依赖：3 之后才能跑 4；5 之后才能跑 6–14（下游全依赖 res_all/deg_tables）。GSEA 的 KEGG 需联网（rest.kegg.jp）。

---

## 4. 关键参数（方法学）

- **导入**：tximport，`txIn=FALSE txOut=FALSE geneIdCol="Name"`（DRAGEN salmon 基因水平）→ DESeqDataSetFromTximport（length offset）
- **过滤（两遍）**：(a) counts≥10 在≥3 样本；(b) 去除任一 timepoint 组全零的基因。32623 → **14161**
- **模型**：`~ replicate + timepoint`（ref=Vehicle/0）
- **批校正**：仅可视化用 `limma::removeBatchEffect(batch=replicate, design=~timepoint)`；DE 检验用 raw counts
- **对比**：Wald 5v0/15v0/15v5 + LRT（reduced `~replicate`）
- **DEG 阈值**：RELAXED = padj<0.05；STRICT = padj<0.05 & |LFC|>0.585（log2(1.5)）
- **independent filtering**：保持开启
- **注释**：org.Rn.eg.db，SYMBOL 85.6%
- **GSEA**：clusterProfiler `gseGO(ont=BP)`+`gseKEGG(rno)`；排序 = Wald `stat` 降序，entrez 去重（|stat| 最大）；minGSSize=15 maxGSSize=500 pvalueCutoff=0.05 pAdjustMethod=BH eps=0 nPermSimple=10000 set.seed(123) seed=TRUE；post-hoc setSize≥15；GO 用 `simplify(cutoff=0.7)` 去冗余

---

## 5. 核心结果（live 核验）

- 14161 基因 × 9 样本；神经元为主培养，三条件组成一致
- **DEG**：5v0 RELAXED 32(↑14↓18)/STRICT 5；15v0 RELAXED 1；15v5 RELAXED 6；LRT 19
- **GSEA 5v0**：GO BP 313 显著（↑285↓28），KEGG 14
- **GSEA 15v5**：GO BP 295（↑31↓264）= 5v0 镜像
- **GSEA 15v0**：GO BP 0 = 已回基线
- **镜像**：5v0 vs 15v5 NES 相关 **r = −0.991**

**结论**：5min Netrin-1 触发协调瞬态重编程（轴突导向/突触程序↑ + 剪接/核糖体/翻译↓），15min 以 r=−0.99 精度全面回归，伴线粒体/OXPHOS 晚发轻升。

---

## 6. 关键对象（results/objects/）

| 文件 | 内容 |
|---|---|
| dds_filtered.rds | 过滤后 DESeqDataSet（14161×9） |
| dds_fitted.rds | DESeq() 拟合后（Wald） |
| dds_lrt.rds | LRT 拟合 |
| res_all.rds | list: res_5v0/15v0/15v5/lrt |
| deg_tables.rds | list: df_5v0/15v0/15v5/lrt |
| vsd.rds | VST 转换 |
| tpm_matrix_raw.rds | TPM（32623×9，过滤前） |
| sample_sheet.rds | 样本表（含 label/condition_label） |
| gene_annotation.csv | ensembl/symbol/entrez |
| sessionInfo_FINAL.txt | R 4.6.0 + 包版本 |

---

## 7. 环境

- R 4.6.0 (2026-04-24 ucrt)，Windows x86_64
- 关键包：DESeq2, tximport, limma, ComplexHeatmap, circlize, clusterProfiler, org.Rn.eg.db, ggplot2, dplyr, ggrepel
- 完整版本见 `results/objects/sessionInfo_FINAL.txt`
