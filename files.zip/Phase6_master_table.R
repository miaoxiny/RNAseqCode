## ============================================================================
## acute Netrin-1 RNA-seq · Phase 6-C · 主结果汇总表（按功能模块）
## 一行一模块：代表基因 / 5min方向 / 15min演变 / GSEA验证 / 证据。
## 代表基因 LFC/padj 从 res_5v0 live 提取；不靠记忆。存 CSV。
## ============================================================================
suppressPackageStartupMessages({ library(DESeq2) })
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"
obj_dir  <- file.path(out_base, "results/objects")
sum_dir  <- file.path(out_base, "results/06_integration")
dir.create(sum_dir, recursive=TRUE, showWarnings=FALSE)

res  <- readRDS(file.path(obj_dir, "res_all.rds"))
anno <- read.csv(file.path(obj_dir, "gene_annotation.csv"), stringsAsFactors=FALSE)
rownames(anno) <- anno$ensembl
d5 <- as.data.frame(res$res_5v0); d5$sym <- anno[rownames(d5),"symbol"]

## 取某基因 5v0 的 "LFC (padj)" 字符串
ginfo <- function(g) {
  r <- d5[which(d5$sym==g)[1], ]
  if (nrow(r)==0 || is.na(r$sym)) return("NA")
  sprintf("%s %+.2f (p=%.1e)", g, r$log2FoldChange, r$padj)
}

## 模块表（代表基因动态填 live 值）
tab <- data.frame(
  Module = c(
    "Splicing / RNA processing",
    "Ribosome biogenesis / translation",
    "Immediate-early genes (IEG)",
    "Cytoskeleton / ROCK",
    "Axon guidance / projection",
    "Synapse assembly",
    "NO–calcium signaling",
    "Adhesion",
    "Mitochondria / OXPHOS (late)"),
  Direction_5min = c(
    "DOWN","DOWN","DOWN","DOWN","UP","UP","UP","UP","(flat at 5min)"),
  Evolution_to_15min = c(
    "recover","recover","rebound (Fos overshoots)","recover",
    "fall back","fall back","fall back","fall back","late rise"),
  Representative_genes = c(
    paste(ginfo("Srsf5"), ginfo("Snrnp70"), sep=" | "),
    "ribosome biogenesis / rRNA / cytoplasmic translation (GSEA)",
    paste(ginfo("Fos"), "| Npas4 -1.75 (p=7.6e-2, LRT-sig)", sep=" "),
    paste(ginfo("Rock1"), "| Rock2 +0.07 (p=1.0, n.s.)", sep=" "),
    ginfo("Cntn2"),
    "synapse/postsynapse assembly (GSEA)",
    paste(ginfo("Nos1"), ginfo("Ryr3"), sep=" | "),
    ginfo("Tln2"),
    "OXPHOS / NADH dehydrogenase (GSEA 15v5, 15v0)"),
  GSEA_5v0 = c(
    "suppressed (NES<0)","suppressed (NES<0)","(single gene)","(single gene)",
    "activated (NES>0)","activated (NES>0)","activated (KEGG Ca signaling)",
    "activated (KEGG CAM/Cadherin)","(not at 5min)"),
  Evidence = c(
    "DEG + GSEA + LRT","GSEA + 15v5 mirror","DEG + LRT","DEG + trajectory(5b)",
    "DEG + GSEA + KEGG","GSEA","DEG + KEGG","DEG + KEGG","GSEA 15v5/15v0"),
  stringsAsFactors = FALSE
)

write.csv(tab, file.path(sum_dir, "Phase6_master_summary_table.csv"), row.names=FALSE)
cat("[saved] Phase6_master_summary_table.csv\n\n")

## 控制台美观打印
for (i in seq_len(nrow(tab))) {
  cat(sprintf("【%s】\n", tab$Module[i]))
  cat(sprintf("  5min: %s  →  15min: %s\n", tab$Direction_5min[i], tab$Evolution_to_15min[i]))
  cat(sprintf("  基因: %s\n", tab$Representative_genes[i]))
  cat(sprintf("  GSEA(5v0): %s | 证据: %s\n\n", tab$GSEA_5v0[i], tab$Evidence[i]))
}
