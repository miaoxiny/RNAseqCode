## ============================================================================
## acute Netrin-1 RNA-seq  ·  04_volcano_v6.R   (Phase 4 · 火山图)
## ----------------------------------------------------------------------------
## v6：x 轴对称 [-6,6]（包住 +5.5 的 NS 点，无截断，发表无争议）。
## v4：只 5v0；三档上色；仅标有 symbol(Fos/mt-Nd4l)；x 轴固定 [-3,3]。
## ============================================================================
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"
obj_dir  <- file.path(out_base, "results/objects")
deg_dir  <- file.path(out_base, "results/03_DEG")

suppressPackageStartupMessages({ library(ggplot2); library(ggrepel); library(dplyr) })

degs <- readRDS(file.path(obj_dir, "deg_tables.rds"))
LFC_CUT <- 0.585; PADJ_CUT <- 0.05

volcano_colors <- c(
  "Up (Strict)"     = "#C73E3E",
  "Down (Strict)"   = "#3B7AB8",
  "Up (Relaxed)"    = "#E9A6A6",
  "Down (Relaxed)"  = "#A8C6E2",
  "Not significant" = "#CFCFCC"
)
col_breaks <- c("Up (Strict)","Down (Strict)","Up (Relaxed)","Down (Relaxed)","Not significant")

df <- degs$df_5v0
title_txt <- "Netrin-1 (5 min) vs Vehicle"

v <- df %>%
  filter(!is.na(padj)) %>%
  mutate(
    neglog10_padj = -log10(padj),
    sig    = padj < PADJ_CUT,
    strict = sig & abs(log2FoldChange) > LFC_CUT,
    category = case_when(
      strict & log2FoldChange > 0 ~ "Up (Strict)",
      strict & log2FoldChange < 0 ~ "Down (Strict)",
      sig    & log2FoldChange > 0 ~ "Up (Relaxed)",
      sig    & log2FoldChange < 0 ~ "Down (Relaxed)",
      TRUE                         ~ "Not significant"
    ),
    has_sym    = !is.na(symbol) & symbol != "",
    label_this = sig & has_sym
  )

v$point_size <- ifelse(v$category != "Not significant", 3.0, 1.3)
v <- v %>% mutate(plot_order = ifelse(category=="Not significant",1,2)) %>% arrange(plot_order)

n_strict <- sum(v$strict); n_relax <- sum(v$sig); n_lab <- sum(v$label_this)
n_su <- sum(v$category=="Up (Strict)"); n_sd <- sum(v$category=="Down (Strict)")
subtitle_text <- sprintf("%s · %d significant (padj<0.05); %d Strict (%d up + %d down); %d labeled (symbol only)",
                         title_txt, n_relax, n_strict, n_su, n_sd, n_lab)

cat(sprintf("=== %s ===\n", title_txt)); print(v %>% count(category))
cat("labeled:", paste(v$symbol[v$label_this], collapse=", "), "\n")

p_5v0 <- ggplot(v, aes(log2FoldChange, neglog10_padj, color=category, size=point_size)) +
  geom_hline(yintercept=-log10(PADJ_CUT), linetype="dashed", color="grey50", linewidth=0.4) +
  geom_vline(xintercept=c(-LFC_CUT, LFC_CUT), linetype="dashed", color="grey50", linewidth=0.4) +
  geom_point(alpha=0.85, stroke=0) +
  scale_color_manual(values=volcano_colors, breaks=col_breaks, name=NULL) +
  scale_size_identity() +
  ggrepel::geom_text_repel(
    data=subset(v, label_this), aes(label=symbol),
    size=3.3, color="grey15", max.overlaps=Inf,
    box.padding=0.5, point.padding=0.3, segment.color="grey60", segment.size=0.3,
    min.segment.length=0, force=5, force_pull=0.5, seed=42, bg.color="white", bg.r=0.15) +
  scale_x_continuous(limits=c(-6, 6), breaks=seq(-6, 6, 2)) +
  labs(title=title_txt, subtitle=subtitle_text,
       x=expression(log[2]~"fold change"),
       y=expression(-log[10]~"adjusted "*italic(p))) +
  theme_bw(base_size=12) +
  theme(panel.grid.minor=element_blank(),
        plot.title=element_text(size=14, face="bold"),
        plot.subtitle=element_text(size=9.5, color="grey40"),
        legend.position="right", legend.text=element_text(size=11),
        legend.key.size=unit(0.7,"cm"), legend.key=element_blank()) +
  guides(color=guide_legend(override.aes=list(size=5)))

print(p_5v0)
ggsave(file.path(deg_dir,"04_volcano_5v0_v6.pdf"), p_5v0, width=9, height=7)
ggsave(file.path(deg_dir,"04_volcano_5v0_v6.png"), p_5v0, width=9, height=7, dpi=300)
cat("\n[fig] 04_volcano_5v0_v6 saved\n")
