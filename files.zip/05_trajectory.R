## ============================================================================
## acute Netrin-1 RNA-seq  ·  05_trajectory.R   (Phase 4 · 时序轨迹图)
## ----------------------------------------------------------------------------
## 6 个基因的时序轨迹：Fos / Rock1 / Snrnp70 / Tln2 / Med13 / Cntn2
## 纵轴 = fold-change vs Vehicle（每基因除以自身 Vehicle 均值，基准=1.0）
## 均值线 + SEM 误差带；横轴 Vehicle→5min→15min。
## 读现成 dds_fitted.rds（归一化 counts），不改主流程。先 print 预览后存。
## ============================================================================
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"
obj_dir  <- file.path(out_base, "results/objects")
fig_dir  <- file.path(out_base, "results/03_DEG")

suppressPackageStartupMessages({ library(DESeq2); library(ggplot2); library(dplyr) })

dds  <- readRDS(file.path(obj_dir, "dds_fitted.rds"))
anno <- read.csv(file.path(obj_dir, "gene_annotation.csv"), stringsAsFactors=FALSE)
rownames(anno) <- anno$ensembl

genes    <- c("Fos","Rock1","Snrnp70","Tln2","Med13","Cntn2")
gene_dir <- c(Fos="down",Rock1="down",Snrnp70="down",Tln2="up",Med13="up",Cntn2="up")
ens <- setNames(anno$ensembl[match(genes, anno$symbol)], genes)
stopifnot(all(!is.na(ens)))

nc  <- counts(dds, normalized=TRUE)
grp <- as.character(colData(dds)$timepoint)

tp_levels <- c("0","5","15")
tp_labels <- c("Vehicle","5 min","15 min")
sem <- function(x) sd(x)/sqrt(length(x))

rows <- list()
for (g in genes) {
  v    <- nc[ens[g], ]
  base <- mean(v[grp=="0"])
  fc   <- v / base
  for (tp in tp_levels) {
    x <- fc[grp==tp]
    rows[[length(rows)+1]] <- data.frame(
      gene=g, dir=gene_dir[g], timepoint=tp, mean=mean(x), sem=sem(x))
  }
}
df <- do.call(rbind, rows)
df$timepoint <- factor(df$timepoint, levels=tp_levels, labels=tp_labels)
df$gene      <- factor(df$gene, levels=genes)

gene_col <- c(
  Fos     ="#1F3A5F",
  Rock1   ="#3B7AB8",
  Snrnp70 ="#5DCAA5",
  Tln2    ="#D85A30",
  Med13   ="#BA7517",
  Cntn2   ="#C73E3E"
)

cat("=== 时序 fold-change（vs Vehicle）===\n")
for (g in genes) {
  s <- df[df$gene==g, ]
  cat(sprintf("%-9s %s: %.2f -> %.2f -> %.2f\n", g, gene_dir[g],
              s$mean[1], s$mean[2], s$mean[3]))
}

p <- ggplot(df, aes(timepoint, mean, color=gene, group=gene)) +
  geom_hline(yintercept=1, linetype="dashed", color="grey60", linewidth=0.4) +
  geom_ribbon(aes(ymin=mean-sem, ymax=mean+sem, fill=gene),
              alpha=0.15, color=NA, show.legend=FALSE) +
  geom_line(linewidth=1) +
  geom_point(size=2.6) +
  scale_color_manual(values=gene_col, name="Gene") +
  scale_fill_manual(values=gene_col) +
  labs(title="Acute time-course trajectories (Netrin-1)",
       subtitle="Expression relative to Vehicle (mean \u00B1 SEM, n=3); dashed line = Vehicle baseline",
       x=NULL, y="Fold-change vs Vehicle") +
  theme_bw(base_size=12) +
  theme(panel.grid.minor=element_blank(),
        plot.title=element_text(size=14, face="bold"),
        plot.subtitle=element_text(size=9.5, color="grey40"),
        legend.position="right")

print(p)
ggsave(file.path(fig_dir,"05_trajectory_6genes.pdf"), p, width=8, height=5.5)
ggsave(file.path(fig_dir,"05_trajectory_6genes.png"), p, width=8, height=5.5, dpi=300)
cat("\n[fig] 05_trajectory_6genes saved\n")
