## ============================================================================
## acute Netrin-1 RNA-seq  ·  01_import_qc_v8.R
## Phase 0 (import + annotate) + Phase 1 (QC: filter -> VST -> corr -> PCA-before)
## ----------------------------------------------------------------------------
## v8 改动：第 6 节过滤加第二道 (6b)「任一时间点组三样本全为 0 即剔」，打掉
##          某组凭空消失→假性巨大 LFC 的假象点（如 048094，5min 组全 0）。
##          留痕 print 被额外剔除的基因。会使过滤后基因数较 v7(14167)略减。
##          全局生效：dds_filtered 重新生成后，Phase 3 DEG/所有图自动一致。
##          需重跑 01(v8) -> 03(重新拟合)。其余与 v7 相同。
## v7 改动：全局显示名 Untreated -> Vehicle。
## v6 改动（封板相关热图 + 全局显示标签）：
##   (a) 样本表加全局列 label（R1_5min，重复在前）与 condition_label
##       （Vehicle/5min Netrin-1/15min Netrin-1）；供后续所有图统一使用。
##   (b) 9b 相关热图封板：行列名用 label；注释条 Replicate(上,灰阶)/Condition(下,绿梯度)，
##       simple_anno_size 加宽至 6mm；先 draw() 预览后再存（先看后存规则）；
##       存为 03_sample_correlation_heatmap_FINAL。
##   (c) 9c PCA 同步：颜色按 Condition、点标注用 label、先 print() 预览后存。
##   (d) 修 SUMMARY：tximport 路径无标量 size factor，改报 normalizationFactors 中位范围。
## v5：相关热图 pheatmap->ComplexHeatmap 对齐 24h。 v3：tximport geneIdCol。 v2：前缀匹配文件名。
## ----------------------------------------------------------------------------
## 本脚本 design-agnostic：用 ~1 占位，只做到「相关热图 + 批校正前 PCA」就停。
## 不跑 DESeq()，不出 dispersion（dispersion 需要 design = 决策节点 ⬥1，
## 等你看完这里的 PCA 决定 ~replicate+timepoint 还是 ~timepoint 后，由 03 出）。
## 跑完请把：results/01_QC 里的 PCA 图 + 控制台最后的 SUMMARY 块 发回。
## 参数全部沿用 24h handoff (v4)。
## ============================================================================

## ---- 0. 用户路径（按你确认） --------------------------------------------------
in_dir   <- "D:/Dropbox/Dropbox/RNAseq 2025/RNA seq acute"      # 9 份 .sf 所在
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"      # 所有产物落这里

VST_BLIND <- TRUE   # 24h 继承默认；QC/PCA 标准做法。要 design-aware 改成 FALSE 即可

## ---- 1. 包检查（只警告，不自动安装） ------------------------------------------
.need_cran <- c("ggplot2","ggrepel","circlize","matrixStats")
.need_bioc <- c("tximport","DESeq2","limma","org.Rn.eg.db","ComplexHeatmap")
.miss_cran <- .need_cran[!vapply(.need_cran, requireNamespace, logical(1), quietly=TRUE)]
.miss_bioc <- .need_bioc[!vapply(.need_bioc, requireNamespace, logical(1), quietly=TRUE)]
if (length(.miss_cran)) message("缺 CRAN 包: ", paste(.miss_cran, collapse=", "),
    "\n  install.packages(c(", paste(sprintf('\"%s\"', .miss_cran), collapse=","), "))")
if (length(.miss_bioc)) message("缺 Bioconductor 包: ", paste(.miss_bioc, collapse=", "),
    "\n  BiocManager::install(c(", paste(sprintf('\"%s\"', .miss_bioc), collapse=","), "))")
if (length(.miss_cran) || length(.miss_bioc)) stop("请先装齐上述包再运行。")

suppressPackageStartupMessages({
  library(DESeq2); library(org.Rn.eg.db); library(ComplexHeatmap); library(circlize)
  library(ggplot2);  library(matrixStats); library(tximport)
})

## ---- 2. 输出文件夹（像 24h 那样分目录） --------------------------------------
.dirs <- c("scripts","results/01_QC","results/02_composition","results/03_DEG",
           "results/04_GSEA","results/05_ORA","results/objects")
for (d in .dirs) dir.create(file.path(out_base, d), recursive=TRUE, showWarnings=FALSE)
qc_dir  <- file.path(out_base, "results/01_QC")
obj_dir <- file.path(out_base, "results/objects")

## ---- 3. 样本表（已确认映射：首位=重复，其余=时间点；前缀匹配真实文件名） ------
samples <- data.frame(
  sample    = c("R1_T0","R1_T5","R1_T15","R2_T0","R2_T5","R2_T15","R3_T0","R3_T5","R3_T15"),
  prefix    = c("10MIN_MPS12351786_D02",  "15MIN_MPS12351786_E02",  "115MIN_MPS12351786_F02",
                "20MIN_MPS12351786_B03",  "25MIN_MPS12351786_C03",  "215MIN_MPS12351786_D03",
                "30MIN_MPS12351786_H03",  "35MIN_MPS12351786_A04",  "315MIN_MPS12351786_B04"),
  timepoint = factor(c("0","5","15","0","5","15","0","5","15"), levels=c("0","5","15")),
  replicate = factor(c("rep1","rep1","rep1","rep2","rep2","rep2","rep3","rep3","rep3")),
  well      = c("D02","E02","F02","B03","C03","D03","H03","A04","B04"),
  stringsAsFactors = FALSE
)
rownames(samples) <- samples$sample

## 用前缀匹配磁盘真实文件名（对 . / _ / 大小写差异稳健）
.all <- list.files(in_dir, pattern="\\.sf$", full.names=FALSE)
samples$file <- vapply(samples$prefix, function(px){
  hit <- .all[startsWith(.all, px)]
  if (length(hit) != 1) stop(sprintf("前缀 '%s' 匹配到 %d 个文件: %s",
                                      px, length(hit), paste(hit, collapse=", ")))
  hit
}, character(1))

files <- file.path(in_dir, samples$file); names(files) <- samples$sample
if (!all(file.exists(files)))
  stop("找不到文件:\n", paste(files[!file.exists(files)], collapse="\n"))
cat("[files] matched 9/9:\n"); print(setNames(samples$file, samples$sample))

## 配色（acute 时间点绿梯度 + 24h replicate 形状） ------------------------------
tp_col    <- c("0"="#E1EAD7", "5"="#6B9A5C", "15"="#264020")   # 0/5/15 min 绿梯度
rep_shape <- c("rep1"=16, "rep2"=17, "rep3"=15)                 # ○ △ □

## ---- 全局显示标签（封板，供后续所有图统一使用；底层 timepoint/sample 不动） ----
## 行列名/点标签：R1_5min（重复在前，紧凑）；注释条/图例：Vehicle/5min/15min Netrin-1
## 注：对照 = PBS as vehicle (5 min)；显示名用 Vehicle（比 Untreated 准确）。
.cond_map  <- c("0"="Vehicle", "5"="5min Netrin-1", "15"="15min Netrin-1")
.short_map <- c("0"="Vehicle", "5"="5min",          "15"="15min")
.rep_num   <- sub("rep","R", samples$replicate)                          # rep1 -> R1
samples$condition_label <- factor(.cond_map[as.character(samples$timepoint)],
                                  levels = c("Vehicle","5min Netrin-1","15min Netrin-1"))
samples$label <- paste0(.rep_num, "_", .short_map[as.character(samples$timepoint)])
# -> R1_Vehicle, R1_5min, R1_15min, R2_Vehicle, ...

cond_col <- setNames(c("#E1EAD7","#6B9A5C","#264020"),                   # 绿梯度(显示名)
                     c("Vehicle","5min Netrin-1","15min Netrin-1"))
rep_anno_col <- c(rep1="#E8E8E8", rep2="#B8B8B8", rep3="#888888")        # 24h 灰阶

## ---- 4. tximport（gene-level，沿用 24h 参数） --------------------------------
txi <- tximport(files, type="salmon", txIn=FALSE, txOut=FALSE,
                geneIdCol="Name", dropInfReps=TRUE)
cat(sprintf("[tximport] raw matrix: %d genes x %d samples\n",
            nrow(txi$counts), ncol(txi$counts)))

## ---- 5. DESeqDataSet（design 占位 ~1；真正 design = ⬥1） ---------------------
dds <- DESeqDataSetFromTximport(txi, colData=samples, design = ~ 1)
n_raw <- nrow(dds)

## ---- 6. 低表达过滤（两道）--------------------------------------------------
## (6a) 24h 口径：counts>=10 in >=3 samples（全局，最小组=3）
## (6b) acute 补充：任一时间点组(0/5/15)三样本全为 0 则剔（打掉如 048094 这种
##      "某组凭空消失→假性巨大 LFC" 的假象点；Phase 0 全局过滤覆盖不到的盲区）。
keep_a <- rowSums(counts(dds) >= 10) >= 3                      # 6a 原条件
.grp   <- colData(dds)$timepoint                              # 0/5/15 分组
keep_b <- apply(counts(dds), 1, function(x)                   # 6b：无任一组全 0
                !any(tapply(x, .grp, function(g) all(g == 0))))
keep   <- keep_a & keep_b

## 留痕：被 6b 额外剔掉的基因（通过了 6a 但因某组全 0 被剔）——methods 可追溯
dropped_b <- rownames(dds)[keep_a & !keep_b]
cat(sprintf("[filter-6b] 因'某组全0'额外剔除 %d 个基因（已通过 counts 过滤但某组三样本全0）:\n",
            length(dropped_b)))
if (length(dropped_b)) print(dropped_b)

dds    <- dds[keep, ]
n_filt <- nrow(dds)
cat(sprintf("[filter] %d -> %d genes (6a counts>=10 in>=3; 6b no all-zero group; removed %d)\n",
            n_raw, n_filt, n_raw - n_filt))

## ---- 7. size factors + VST（仅可视化用；统计检验后续用原始 counts） -----------
dds <- estimateSizeFactors(dds)
## tximport 路径用逐基因 normalizationFactors 矩阵，sizeFactors(dds) 为 NULL。
## 取各样本中位 normalization factor 作报告（标量 size factor 不适用此路径）。
nf_med <- if (!is.null(normalizationFactors(dds)))
            apply(normalizationFactors(dds), 2, median) else sizeFactors(dds)
vsd <- vst(dds, blind = VST_BLIND)
vmat <- assay(vsd)

## ---- 8. 注释 ENSEMBL -> SYMBOL / ENTREZID（org.Rn.eg.db） --------------------
ens <- rownames(dds)
sym <- mapIds(org.Rn.eg.db, keys=ens, column="SYMBOL",   keytype="ENSEMBL", multiVals="first")
ent <- mapIds(org.Rn.eg.db, keys=ens, column="ENTREZID", keytype="ENSEMBL", multiVals="first")
sym_cov <- mean(!is.na(sym)); ent_cov <- mean(!is.na(ent))
anno <- data.frame(ensembl=ens, symbol=unname(sym), entrez=unname(ent), stringsAsFactors=FALSE)
write.csv(anno, file.path(obj_dir, "gene_annotation.csv"), row.names=FALSE)

## ---- 9a. 文库 QC 条形图（深度 + 检出基因数） --------------------------------
detected <- colSums(counts(dds) > 0)
qc_df <- data.frame(sample=colnames(dds),
                    timepoint=samples[colnames(dds),"timepoint"],
                    lib_M=colSums(counts(dds))/1e6,
                    detected=detected)
qc_df$sample <- factor(qc_df$sample, levels=samples$sample)

p_lib <- ggplot(qc_df, aes(sample, lib_M, fill=timepoint)) +
  geom_col(color="grey30", width=.75) +
  scale_fill_manual(values=tp_col, name="Timepoint (min)") +
  labs(title="Library size (filtered, post-size-factor counts sum)",
       subtitle=sprintf("range %.1f-%.1f M (mean %.1f M)",
                        min(qc_df$lib_M), max(qc_df$lib_M), mean(qc_df$lib_M)),
       x=NULL, y="Counts (millions)") +
  theme_bw() + theme(axis.text.x=element_text(angle=45, hjust=1))

p_det <- ggplot(qc_df, aes(sample, detected, fill=timepoint)) +
  geom_col(color="grey30", width=.75) +
  scale_fill_manual(values=tp_col, name="Timepoint (min)") +
  labs(title="Detected genes per sample (counts > 0, filtered set)",
       subtitle=sprintf("range %d-%d", min(detected), max(detected)),
       x=NULL, y="# genes") +
  theme_bw() + theme(axis.text.x=element_text(angle=45, hjust=1))

ggsave(file.path(qc_dir,"01_library_size.pdf"), p_lib, width=7, height=4.5)
ggsave(file.path(qc_dir,"01_library_size.png"), p_lib, width=7, height=4.5, dpi=150)
ggsave(file.path(qc_dir,"02_detected_genes.pdf"), p_det, width=7, height=4.5)
ggsave(file.path(qc_dir,"02_detected_genes.png"), p_det, width=7, height=4.5, dpi=150)

## ---- 9b. 样本相关性热图（ComplexHeatmap，封板版） ----------------------------
## 色阶/格子/聚类照 24h 的 03_QC.R；注释条 Replicate 在上(灰阶)/ Condition 在下(绿梯度)；
## 行列名用全局 samples$label（R1_5min…）；注释条加宽 simple_anno_size=6mm。
cormat <- cor(vmat, method="pearson")
write.csv(cormat, file.path(obj_dir,"sample_correlation_matrix.csv"))

## 用全局显示标签重命名行列（按列顺序对齐 samples）
idx <- match(colnames(cormat), samples$sample)
cormat_lab <- cormat
dimnames(cormat_lab) <- list(samples$label[idx], samples$label[idx])

ha <- HeatmapAnnotation(
  Replicate = samples$replicate[idx],          # 在上（灰阶）
  Condition = samples$condition_label[idx],    # 在下（绿梯度，三个显示标签）
  col = list(Replicate = rep_anno_col, Condition = cond_col),
  annotation_name_side = "left",
  annotation_name_gp   = gpar(fontsize = 8),
  simple_anno_size     = unit(6, "mm"),        # 加宽（封板）
  border               = TRUE
)

## 相关图专用色阶：白 -> 中蓝 -> 深海军蓝（24h 原值，非 z-score 蓝白红）
col_fun <- circlize::colorRamp2(
  c(min(cormat), (min(cormat) + 1) / 2, 1),
  c("#F7F7F7", "#92B4C8", "#1F3A5F")
)

hm <- Heatmap(
  cormat_lab, name = "Pearson r", col = col_fun, top_annotation = ha,
  show_row_names = TRUE, show_column_names = TRUE,
  row_names_gp = gpar(fontsize = 9), column_names_gp = gpar(fontsize = 9),
  cluster_rows = TRUE, cluster_columns = TRUE,
  rect_gp = gpar(col = "white", lwd = 0.4), border = TRUE,
  column_title = "Sample-to-sample correlation (VST, Pearson)",
  column_title_gp = gpar(fontsize = 11, fontface = "plain"),
  heatmap_legend_param = list(title_gp = gpar(fontsize = 9),
                              labels_gp = gpar(fontsize = 8),
                              legend_height = unit(3, "cm"))
)

## 工作规则：先屏幕预览，满意后再存盘
draw(hm)                                        # ← 先看这张
## —— 预览满意后，运行以下 4 行存盘（封板版命名）——
pdf(file.path(qc_dir, "03_sample_correlation_heatmap_FINAL.pdf"), width = 7, height = 6)
draw(hm); dev.off()
png(file.path(qc_dir, "03_sample_correlation_heatmap_FINAL.png"),
    width = 7, height = 6, units = "in", res = 150); draw(hm); dev.off()
cat("[fig] 03_sample_correlation_heatmap_FINAL saved\n")

## ---- 9c. PCA（批校正前；top-500 高变基因） ----------------------------------
rv      <- matrixStats::rowVars(vmat)
top500  <- order(rv, decreasing=TRUE)[seq_len(min(500, length(rv)))]
pca     <- prcomp(t(vmat[top500, , drop=FALSE]), center=TRUE, scale.=FALSE)
pctvar  <- round(100 * pca$sdev^2 / sum(pca$sdev^2), 1)
pca_df  <- data.frame(samples[rownames(pca$x), ], pca$x[, 1:4])
write.csv(pca_df, file.path(obj_dir,"pca_before_coords.csv"), row.names=FALSE)

p_pca <- ggplot(pca_df, aes(PC1, PC2, color=condition_label, shape=replicate)) +
  geom_point(size=4, stroke=1.1) +
  scale_color_manual(values=cond_col, name="Condition") +
  scale_shape_manual(values=rep_shape, name="Replicate") +
  ggrepel::geom_text_repel(aes(label=label), size=3, color="grey30",
                           max.overlaps=Inf, show.legend=FALSE) +
  labs(title="PCA (top-500 var genes, VST, BEFORE batch correction)",
       subtitle=sprintf("PC1 %.1f%% | PC2 %.1f%% | PC3 %.1f%% | PC4 %.1f%%",
                        pctvar[1],pctvar[2],pctvar[3],pctvar[4]),
       x=sprintf("PC1 (%.1f%%)", pctvar[1]),
       y=sprintf("PC2 (%.1f%%)", pctvar[2])) +
  theme_bw()

## 工作规则：先屏幕预览，满意后再存盘
print(p_pca)                                    # ← 先看这张
## —— 预览满意后，运行以下 2 行存盘 ——
ggsave(file.path(qc_dir,"04_PCA_before_correction.pdf"), p_pca, width=7, height=5.5)
ggsave(file.path(qc_dir,"04_PCA_before_correction.png"), p_pca, width=7, height=5.5, dpi=150)

## ---- 10. 保存对象（供回传给我做后续/核对） ----------------------------------
saveRDS(dds,     file.path(obj_dir,"dds_filtered.rds"))
saveRDS(vsd,     file.path(obj_dir,"vsd.rds"))
saveRDS(samples, file.path(obj_dir,"sample_sheet.rds"))
saveRDS(list(pca=pca, pctvar=pctvar, df=pca_df), file.path(obj_dir,"pca_before.rds"))

## ---- 11. 控制台 SUMMARY（请整段复制发回给我） -------------------------------
cat("\n================= SUMMARY (copy this block back) =================\n")
cat(sprintf("raw genes              : %d\n", n_raw))
cat(sprintf("after low-count filter : %d (removed %d)\n", n_filt, n_raw-n_filt))
cat(sprintf("samples                : %d\n", ncol(dds)))
cat(sprintf("SYMBOL coverage        : %.1f%%   ENTREZID coverage: %.1f%%\n",
            100*sym_cov, 100*ent_cov))
cat(sprintf("norm factor (median/sample): %.3f - %.3f  [tximport offset path]\n",
            min(nf_med), max(nf_med)))
cat(sprintf("library size (M)       : %.1f - %.1f (mean %.1f)\n",
            min(qc_df$lib_M), max(qc_df$lib_M), mean(qc_df$lib_M)))
cat(sprintf("detected genes         : %d - %d\n", min(detected), max(detected)))
cat(sprintf("correlation r          : %.4f - %.4f (mean %.4f)\n",
            min(cormat[upper.tri(cormat)]), max(cormat[upper.tri(cormat)]),
            mean(cormat[upper.tri(cormat)])))
cat(sprintf("PCA var explained      : PC1 %.1f%% / PC2 %.1f%% / PC3 %.1f%% / PC4 %.1f%%\n",
            pctvar[1],pctvar[2],pctvar[3],pctvar[4]))
cat("PCA PC1/PC2 by sample:\n")
print(round(pca_df[, c("PC1","PC2")], 2))
cat("=================================================================\n")
cat("\n下一步：把 results/01_QC/04_PCA_before_correction 图 + 上面 SUMMARY 发我，\n")
cat("我们据此定 ⬥1 建模公式（~replicate+timepoint vs ~timepoint，及是否批校正可视化）。\n")

## sessionInfo 存档（可复现）
writeLines(capture.output(sessionInfo()), file.path(obj_dir,"sessionInfo_01.txt"))
