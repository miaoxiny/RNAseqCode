## ============================================================================
## acute Netrin-1 RNA-seq  ·  08_gsea_5v0.R   (Phase 5 · GSEA 5v0)
## clusterProfiler gseGO(BP)+gseKEGG(rno)；Wald stat 排序，entrez 去重(|stat|最大)；
## minGSSize=15 maxGSSize=500 pvalueCutoff=0.05 pAdjust=BH eps=0 nPermSimple=10000
## seed=123；post-hoc setSize>=15。+ simplify(cutoff=0.7)。存 rds/csv。
## ============================================================================
suppressPackageStartupMessages({
  library(dplyr); library(clusterProfiler); library(org.Rn.eg.db); library(AnnotationDbi)
})
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"
obj_dir  <- file.path(out_base, "results/objects")
gsea_dir <- file.path(out_base, "results/04_GSEA")
dir.create(gsea_dir, recursive=TRUE, showWarnings=FALSE)

res  <- readRDS(file.path(obj_dir, "res_all.rds"))$res_5v0
df   <- as.data.frame(res); df$ensembl <- rownames(df)
anno <- read.csv(file.path(obj_dir, "gene_annotation.csv"), stringsAsFactors=FALSE)
rownames(anno) <- anno$ensembl
df$entrez_id <- anno[df$ensembl, "entrez"]

ranked <- df %>% dplyr::filter(!is.na(entrez_id), !is.na(stat)) %>%
  dplyr::group_by(entrez_id) %>%
  dplyr::slice_max(order_by=abs(stat), n=1, with_ties=FALSE) %>% dplyr::ungroup()
geneList <- sort(setNames(ranked$stat, ranked$entrez_id), decreasing=TRUE)

set.seed(123)
gsea_go <- gseGO(geneList=geneList, OrgDb=org.Rn.eg.db, ont="BP", keyType="ENTREZID",
  minGSSize=15, maxGSSize=500, pvalueCutoff=0.05, pAdjustMethod="BH",
  eps=0, nPermSimple=10000, seed=TRUE, verbose=FALSE)
gsea_go <- setReadable(gsea_go, OrgDb=org.Rn.eg.db, keyType="ENTREZID")
gsea_go@result$direction <- ifelse(gsea_go@result$NES>0,"activated","suppressed")
gsea_go@result <- gsea_go@result %>% dplyr::filter(setSize>=15)

set.seed(123)
gsea_kegg <- gseKEGG(geneList=geneList, organism="rno", keyType="kegg",
  minGSSize=15, maxGSSize=500, pvalueCutoff=0.05, pAdjustMethod="BH",
  eps=0, nPermSimple=10000, seed=TRUE, verbose=FALSE)
gsea_kegg <- setReadable(gsea_kegg, OrgDb=org.Rn.eg.db, keyType="ENTREZID")
gsea_kegg@result$direction <- ifelse(gsea_kegg@result$NES>0,"activated","suppressed")
gsea_kegg@result <- gsea_kegg@result %>% dplyr::filter(setSize>=15)

gsea_go_simp <- simplify(gsea_go, cutoff=0.7, by="p.adjust", select_fun=min)

saveRDS(gsea_go,   file.path(gsea_dir,"GSEA_GO_BP_5v0.rds"))
write.csv(gsea_go@result, file.path(gsea_dir,"GSEA_GO_BP_5v0.csv"), row.names=FALSE)
saveRDS(gsea_kegg, file.path(gsea_dir,"GSEA_KEGG_5v0.rds"))
write.csv(gsea_kegg@result, file.path(gsea_dir,"GSEA_KEGG_5v0.csv"), row.names=FALSE)
saveRDS(gsea_go_simp, file.path(gsea_dir,"GSEA_GO_BP_5v0_simplified.rds"))
write.csv(gsea_go_simp@result, file.path(gsea_dir,"GSEA_GO_BP_5v0_simplified.csv"), row.names=FALSE)
cat(sprintf("[5v0] GO BP %d sig | KEGG %d sig | simplified %d\n",
  sum(gsea_go@result$p.adjust<0.05), sum(gsea_kegg@result$p.adjust<0.05),
  sum(gsea_go_simp@result$p.adjust<0.05)))
