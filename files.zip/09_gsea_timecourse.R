## ============================================================================
## acute Netrin-1 RNA-seq  ·  09_gsea_timecourse.R   (Phase 5 · GSEA 15v5 + 15v0)
## 同 08 参数，数据源换 res_15v5 / res_15v0。看时序演变：
##   15v5 = 5v0 镜像（轴突↓/生物合成↑=回归）；15v0 信号弱（已回基线）。
## 存各自 GO BP + KEGG 的 csv。
## ============================================================================
suppressPackageStartupMessages({
  library(dplyr); library(clusterProfiler); library(org.Rn.eg.db); library(AnnotationDbi)
})
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"
obj_dir  <- file.path(out_base, "results/objects")
gsea_dir <- file.path(out_base, "results/04_GSEA")

res_all <- readRDS(file.path(obj_dir, "res_all.rds"))
anno    <- read.csv(file.path(obj_dir, "gene_annotation.csv"), stringsAsFactors=FALSE)
rownames(anno) <- anno$ensembl

run_gsea <- function(res, tag) {
  df <- as.data.frame(res); df$ensembl <- rownames(df)
  df$entrez_id <- anno[df$ensembl, "entrez"]
  ranked <- df %>% dplyr::filter(!is.na(entrez_id), !is.na(stat)) %>%
    dplyr::group_by(entrez_id) %>%
    dplyr::slice_max(order_by=abs(stat), n=1, with_ties=FALSE) %>% dplyr::ungroup()
  gl <- sort(setNames(ranked$stat, ranked$entrez_id), decreasing=TRUE)
  set.seed(123)
  go <- gseGO(geneList=gl, OrgDb=org.Rn.eg.db, ont="BP", keyType="ENTREZID",
    minGSSize=15, maxGSSize=500, pvalueCutoff=0.05, pAdjustMethod="BH",
    eps=0, nPermSimple=10000, seed=TRUE, verbose=FALSE)
  go <- setReadable(go, OrgDb=org.Rn.eg.db, keyType="ENTREZID")
  go@result$direction <- ifelse(go@result$NES>0,"activated","suppressed")
  go@result <- go@result %>% dplyr::filter(setSize>=15)
  set.seed(123)
  kg <- gseKEGG(geneList=gl, organism="rno", keyType="kegg",
    minGSSize=15, maxGSSize=500, pvalueCutoff=0.05, pAdjustMethod="BH",
    eps=0, nPermSimple=10000, seed=TRUE, verbose=FALSE)
  kg <- setReadable(kg, OrgDb=org.Rn.eg.db, keyType="ENTREZID")
  kg@result$direction <- ifelse(kg@result$NES>0,"activated","suppressed")
  kg@result <- kg@result %>% dplyr::filter(setSize>=15)
  write.csv(go@result, file.path(gsea_dir, sprintf("GSEA_GO_BP_%s.csv",tag)), row.names=FALSE)
  write.csv(kg@result, file.path(gsea_dir, sprintf("GSEA_KEGG_%s.csv",tag)), row.names=FALSE)
  cat(sprintf("[%s] GO BP %d sig | KEGG %d sig\n", tag,
    sum(go@result$p.adjust<0.05), sum(kg@result$p.adjust<0.05)))
}

run_gsea(res_all$res_15v5, "15v5")
run_gsea(res_all$res_15v0, "15v0")
