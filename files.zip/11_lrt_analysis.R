## ============================================================================
## acute Netrin-1 RNA-seq  ·  11_lrt_analysis.R   (Phase 3 补 · LRT 分析)
## LRT (full ~rep+timepoint vs reduced ~rep) 19 基因：symbol + padj + 0/5/15
## 趋势分类 + 是否在 5v0 RELAXED。存 DEG_LRT_19_annotated.csv。
## ============================================================================
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"
obj_dir  <- file.path(out_base, "results/objects")
deg_dir  <- file.path(out_base, "results/03_DEG")
suppressPackageStartupMessages({ library(DESeq2) })

dds   <- readRDS(file.path(obj_dir, "dds_fitted.rds"))
degs  <- readRDS(file.path(obj_dir, "deg_tables.rds"))
anno  <- read.csv(file.path(obj_dir, "gene_annotation.csv"), stringsAsFactors=FALSE)
rownames(anno) <- anno$ensembl

lrt_sig <- degs$df_lrt[!is.na(degs$df_lrt$padj) & degs$df_lrt$padj<0.05, ]
lrt_sig <- lrt_sig[order(lrt_sig$padj), ]
in5v0   <- degs$df_5v0[!is.na(degs$df_5v0$padj) & degs$df_5v0$padj<0.05, "ensembl"]

nc  <- counts(dds, normalized=TRUE); grp <- as.character(colData(dds)$timepoint)
tmean <- function(e) c(mean(nc[e,grp=="0"]), mean(nc[e,grp=="5"]), mean(nc[e,grp=="15"]))
classify <- function(v){ d5<-(v[2]-v[1])/v[1]; d15<-(v[3]-v[1])/v[1]; thr<-0.10
  s5<-ifelse(abs(d5)<thr,"flat",ifelse(d5>0,"up","down"))
  s15<-ifelse(abs(d15)<thr,"flat",ifelse(d15>0,"up","down"))
  if(s5!="flat"&&s15=="flat") return(paste0("5min pulse (",s5,", recover)"))
  if(s5!="flat"&&s5==s15&&abs(d15)>abs(d5)) return(paste0("monotonic ",s5))
  if(s5=="flat"&&s15!="flat") return(paste0("delayed (15min ",s15,")"))
  paste0("5min ",s5,", 15min ",s15) }

out <- data.frame(
  symbol=sapply(lrt_sig$ensembl,function(e){s<-anno[e,"symbol"];if(is.na(s)||s=="")NA else s}),
  ensembl=lrt_sig$ensembl, LRT_padj=signif(lrt_sig$padj,3),
  Vehicle_mean=round(sapply(lrt_sig$ensembl,function(e)tmean(e)[1]),1),
  min5_mean=round(sapply(lrt_sig$ensembl,function(e)tmean(e)[2]),1),
  min15_mean=round(sapply(lrt_sig$ensembl,function(e)tmean(e)[3]),1),
  trend=sapply(lrt_sig$ensembl,function(e)classify(tmean(e))),
  in_5v0_RELAXED=ifelse(lrt_sig$ensembl %in% in5v0,"yes","no"),
  stringsAsFactors=FALSE, row.names=NULL)
write.csv(out, file.path(deg_dir,"DEG_LRT_19_annotated.csv"), row.names=FALSE)
cat(sprintf("[saved] DEG_LRT_19_annotated.csv (%d genes, overlap 5v0=%d)\n",
  nrow(out), sum(out$in_5v0_RELAXED=="yes")))
