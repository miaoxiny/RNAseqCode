## ============================================================================
## acute Netrin-1 RNA-seq  ·  01b_pca_after_v2.R
## ⬥1b 可视化：批校正后 PCA（limma::removeBatchEffect 扣 replicate）
## ----------------------------------------------------------------------------
## v2 改动：(a) Untreated->Vehicle（全局统一）；(b) 修第4步 round bug（label 不参与
##          round）；(c) 副标题回写 "visualization only" caveat + 补 PC3/PC4；
##          存 05_PCA_after_correction_FINAL（宽度 7.5）。与封板图一致、可复现。
## ----------------------------------------------------------------------------
## 目的：扣掉 replicate(batch) 后看 condition 信号能否浮出来，验证「condition 被
##       batch 盖住」的判断；并作为与 04_PCA_before_correction 配对的成品图。
## 重要：本图【仅用于可视化】。DEG 统计检验仍用原始 counts + ~replicate+timepoint，
##       removeBatchEffect 不进检验（沿用 24h 规矩）。
## 依赖现成对象：results/objects/vsd.rds（v6 的 VST 结果）。
## label/condition_label 就地重建（不依赖旧 sample_sheet.rds）。
## 工作规则：先 print() 屏幕预览，满意后再运行存盘那几行。
## ============================================================================

## ---- 0. 路径（与 01 一致） ---------------------------------------------------
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"
qc_dir   <- file.path(out_base, "results/01_QC")
obj_dir  <- file.path(out_base, "results/objects")

suppressPackageStartupMessages({
  library(limma); library(ggplot2); library(matrixStats); library(DESeq2)
})

## ---- 1. 读 VST 对象 ---------------------------------------------------------
vsd  <- readRDS(file.path(obj_dir, "vsd.rds"))
vmat <- assay(vsd)
cd   <- as.data.frame(colData(vsd))          # 含 timepoint / replicate / sample
stopifnot(all(c("timepoint","replicate") %in% colnames(cd)))

## ---- 2. 就地重建全局显示标签（与 v6 一致，不依赖旧存盘） ---------------------
.cond_map  <- c("0"="Vehicle", "5"="5min Netrin-1", "15"="15min Netrin-1")
.short_map <- c("0"="Vehicle", "5"="5min",          "15"="15min")
.rep_num   <- sub("rep","R", as.character(cd$replicate))
cd$condition_label <- factor(.cond_map[as.character(cd$timepoint)],
                             levels = c("Vehicle","5min Netrin-1","15min Netrin-1"))
cd$label <- paste0(.rep_num, "_", .short_map[as.character(cd$timepoint)])

cond_col  <- setNames(c("#E1EAD7","#6B9A5C","#264020"),
                      c("Vehicle","5min Netrin-1","15min Netrin-1"))
rep_shape <- c("rep1"=16, "rep2"=17, "rep3"=15)

## ---- 3. 批校正（仅作图）：扣 replicate，保护 condition ----------------------
## design=~timepoint 告诉 removeBatchEffect 保留 condition 相关变异，不要一起扣掉
vmat_bc <- limma::removeBatchEffect(
  vmat,
  batch  = cd$replicate,
  design = model.matrix(~ timepoint, data = cd)
)

## ---- 4. PCA（批校正后；top-500 高变基因，同 01 口径） -----------------------
rv     <- matrixStats::rowVars(vmat_bc)
top500 <- order(rv, decreasing=TRUE)[seq_len(min(500, length(rv)))]
pca    <- prcomp(t(vmat_bc[top500, , drop=FALSE]), center=TRUE, scale.=FALSE)
pctvar <- round(100 * pca$sdev^2 / sum(pca$sdev^2), 1)
pca_df <- data.frame(cd[rownames(pca$x), ], pca$x[, 1:4])
write.csv(pca_df, file.path(obj_dir,"pca_after_coords.csv"), row.names=FALSE)

cat("\n=== PCA AFTER batch correction — var explained ===\n")
cat(sprintf("PC1 %.1f%% / PC2 %.1f%% / PC3 %.1f%% / PC4 %.1f%%\n",
            pctvar[1],pctvar[2],pctvar[3],pctvar[4]))
cat("PC1/PC2 by sample:\n")
print(data.frame(label = pca_df$label, round(pca_df[, c("PC1","PC2")], 2)))

## ---- 5. 画图（先预览，后存盘） ----------------------------------------------
p_after <- ggplot(pca_df, aes(PC1, PC2, color=condition_label, shape=replicate)) +
  geom_point(size=4, stroke=1.1) +
  scale_color_manual(values=cond_col, name="Condition") +
  scale_shape_manual(values=rep_shape, name="Replicate") +
  ggrepel::geom_text_repel(aes(label=label), size=3, color="grey30",
                           max.overlaps=Inf, show.legend=FALSE) +
  labs(title="PCA (top-500 var genes, VST, AFTER batch correction)",
       subtitle=sprintf(paste0("removeBatchEffect(batch=replicate, design=~timepoint)",
                               " — visualization only; DE testing uses raw counts\n",
                               "PC1 %.1f%% | PC2 %.1f%% | PC3 %.1f%% | PC4 %.1f%%"),
                        pctvar[1], pctvar[2], pctvar[3], pctvar[4]),
       x=sprintf("PC1 (%.1f%%)", pctvar[1]),
       y=sprintf("PC2 (%.1f%%)", pctvar[2])) +
  theme_bw()

## 工作规则：先屏幕预览
print(p_after)                                   # ← 先看这张
## —— 预览满意后，运行以下 2 行存盘（封板版，宽度 7.5 给 caveat 留行）——
ggsave(file.path(qc_dir,"05_PCA_after_correction_FINAL.pdf"), p_after, width=7.5, height=5.5)
ggsave(file.path(qc_dir,"05_PCA_after_correction_FINAL.png"), p_after, width=7.5, height=5.5, dpi=150)
cat("[fig] 05_PCA_after_correction_FINAL saved\n")
