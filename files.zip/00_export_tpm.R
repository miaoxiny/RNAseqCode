## ============================================================================
## acute Netrin-1 RNA-seq  ·  00_export_tpm.R   （独立：只生成 TPM 矩阵）
## 重新 tximport 一次拿 txi$abundance(TPM)，存 tpm_matrix_raw.rds。不动其他脚本。
## Phase 2 细胞组成核查用（需过滤前 32623 全基因，含低表达 marker）。
## ============================================================================
in_dir   <- "D:/Dropbox/Dropbox/RNAseq 2025/RNA seq acute"
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"
obj_dir  <- file.path(out_base, "results/objects")
suppressPackageStartupMessages({ library(tximport) })

samples <- data.frame(
  sample = c("R1_T0","R1_T5","R1_T15","R2_T0","R2_T5","R2_T15","R3_T0","R3_T5","R3_T15"),
  prefix = c("10MIN_MPS12351786_D02","15MIN_MPS12351786_E02","115MIN_MPS12351786_F02",
             "20MIN_MPS12351786_B03","25MIN_MPS12351786_C03","215MIN_MPS12351786_D03",
             "30MIN_MPS12351786_H03","35MIN_MPS12351786_A04","315MIN_MPS12351786_B04"),
  stringsAsFactors = FALSE)
rownames(samples) <- samples$sample

.all <- list.files(in_dir, pattern="\\.sf$", full.names=FALSE)
samples$file <- vapply(samples$prefix, function(px){
  hit <- .all[startsWith(.all, px)]
  if (length(hit) != 1) stop(sprintf("前缀 '%s' 匹配到 %d 个文件", px, length(hit)))
  hit
}, character(1))
files <- file.path(in_dir, samples$file); names(files) <- samples$sample
stopifnot(all(file.exists(files)))

txi <- tximport(files, type="salmon", txIn=FALSE, txOut=FALSE,
                geneIdCol="Name", dropInfReps=TRUE)
tpm <- txi$abundance
cat(sprintf("[tpm] %d genes x %d samples\n", nrow(tpm), ncol(tpm)))
saveRDS(tpm, file.path(obj_dir, "tpm_matrix_raw.rds"))
cat("[saved] tpm_matrix_raw.rds\n")
