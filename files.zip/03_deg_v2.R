## ============================================================================
## acute Netrin-1 RNA-seq  ·  03_deg_v2.R   (Phase 3 · 差异表达)
## ----------------------------------------------------------------------------
## v2 改动：仅改第 3 节方向校验的【注释与打印文字】，使其与真实结果自洽——
##   Fos 等在 5min 为负 LFC = Netrin 急性抑制(真实，非方向 bug；对照为 PBS vehicle)。
##   原版误标"⚠检查方向"会误导。计算逻辑/结果/存盘【完全不变】。
## ----------------------------------------------------------------------------
## 模型：~ replicate + timepoint （⬥1 已定，ref = 0min/Untreated）
## 对比（⬥2 全做）：
##   - 5min  vs 0min   (Wald, coef timepoint_5_vs_0)
##   - 15min vs 0min   (Wald, coef timepoint_15_vs_0)
##   - 15min vs 5min   (Wald, contrast c("timepoint","15","5"))
##   - LRT (full ~replicate+timepoint vs reduced ~replicate) — 随时间变化基因集
## DEG 两档（沿用 24h）：STRICT = padj<0.05 & |LFC|>0.585(unshrunken)；RELAXED = padj<0.05
## GSEA 用 Wald stat 排序（Phase 5）；本脚本只到「拟合+方向校验+计数+存对象」，不画图。
## 所有计数 live print 全分解，不预报数字。
## 输入：results/objects/dds_filtered.rds（v6，已过滤+offset，design=~1 占位）
## ============================================================================

## ---- 0. 路径 ----------------------------------------------------------------
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"
obj_dir  <- file.path(out_base, "results/objects")
deg_dir  <- file.path(out_base, "results/03_DEG")
dir.create(deg_dir, recursive=TRUE, showWarnings=FALSE)

suppressPackageStartupMessages({ library(DESeq2) })

## ---- 1. 读 dds + 注释，设 design --------------------------------------------
dds  <- readRDS(file.path(obj_dir, "dds_filtered.rds"))
anno <- read.csv(file.path(obj_dir, "gene_annotation.csv"), stringsAsFactors=FALSE)
rownames(anno) <- anno$ensembl

## ref 设为 0（Untreated 基线），design 换成正式模型
dds$timepoint <- relevel(factor(dds$timepoint), ref="0")
dds$replicate <- factor(dds$replicate)
design(dds)   <- ~ replicate + timepoint

LFC_CUT  <- 0.585     # log2(1.5)
PADJ_CUT <- 0.05

## ---- 2. 拟合（Wald，用于三个 pairwise） -------------------------------------
dds <- DESeq(dds)                       # ~replicate+timepoint, Wald
cat("[fit] resultsNames(dds):\n"); print(resultsNames(dds))

## ---- 3. 系数方向确认 + 锚点 IEG 观察 ----------------------------------------
## 方向由 ref 决定：dds ref=0(Vehicle)，故 timepoint_5_vs_0 的【正 LFC = 5min 相对
## Vehicle 上调，负 LFC = 下调】。方向本身由 relevel 固定，无需靠某基因"应该上/下"来判。
## 锚点 IEG(Fos/Egr1/Arc)在此【仅作观察】打印，不作 pass/fail：
##   ⚠ 实测结果：Fos 等在 5min 为【负】LFC（5min Netrin 显著压低 Fos，LFC≈-2.35,
##   padj≈2.7e-3）。这【不是方向 bug】——对照为 PBS vehicle(5min)、三组操作平衡，
##   故该下调是【真实的 Netrin 急性抑制效应】，非经典 IEG 诱导。详见 Phase 3 结论。
anchor_sym <- c("Fos","Egr1","Arc")
anchor_ens <- anno$ensembl[match(anchor_sym, anno$symbol)]
res_5v0_chk <- results(dds, name="timepoint_5_vs_0")
cat("\n=== 锚点 IEG 观察 (5min vs Vehicle) — 仅报告方向，不作 pass/fail ===\n")
for (i in seq_along(anchor_sym)) {
  e <- anchor_ens[i]
  if (is.na(e) || !e %in% rownames(res_5v0_chk)) {
    cat(sprintf("  %-5s : 未找到/被过滤\n", anchor_sym[i]))
  } else {
    r <- res_5v0_chk[e, ]
    dir <- ifelse(is.na(r$log2FoldChange), "NA",
                  ifelse(r$log2FoldChange>0, "↑ up vs Vehicle", "↓ down vs Vehicle"))
    cat(sprintf("  %-5s (%s): LFC=%+.2f  padj=%.2e  %s\n",
                anchor_sym[i], e, r$log2FoldChange, r$padj, dir))
  }
}
cat("→ 方向口径：正 LFC = 相对 Vehicle 上调。实测 Fos 等为负 = Netrin 急性抑制(真实，非 bug)。\n")

## ---- 4. 取对比的小函数 + 计数全分解 -----------------------------------------
annotate_res <- function(res) {
  df <- as.data.frame(res)
  df$ensembl <- rownames(df)
  df$symbol  <- anno[df$ensembl, "symbol"]
  df$entrez  <- anno[df$ensembl, "entrez"]
  df
}
report_counts <- function(df, tag) {
  total  <- nrow(df)
  na_padj<- sum(is.na(df$padj))
  tested <- total - na_padj
  relaxed<- df$padj < PADJ_CUT & !is.na(df$padj)
  strict <- relaxed & abs(df$log2FoldChange) > LFC_CUT
  r_up<-sum(relaxed & df$log2FoldChange>0); r_dn<-sum(relaxed & df$log2FoldChange<0)
  s_up<-sum(strict  & df$log2FoldChange>0); s_dn<-sum(strict  & df$log2FoldChange<0)
  s_sym<-sum(strict & !is.na(df$symbol) & df$symbol!="")
  cat(sprintf("\n────────── %s ──────────\n", tag))
  cat(sprintf("  total genes              : %d\n", total))
  cat(sprintf("  NA padj (indep. filter)  : %d\n", na_padj))
  cat(sprintf("  tested (non-NA padj)     : %d\n", tested))
  cat(sprintf("  RELAXED (padj<%.2f)       : %d  (%d up + %d down)\n",
              PADJ_CUT, sum(relaxed), r_up, r_dn))
  cat(sprintf("  STRICT  (& |LFC|>%.3f)   : %d  (%d up + %d down)\n",
              LFC_CUT, sum(strict), s_up, s_dn))
  cat(sprintf("    STRICT w/ symbol       : %d   w/o symbol: %d\n",
              s_sym, sum(strict)-s_sym))
  cat(sprintf("  checksum total=NA+tested : %d = %d + %d  %s\n",
              total, na_padj, tested, ifelse(total==na_padj+tested,"OK","!!")))
  invisible(list(strict=df[strict,], relaxed=df[relaxed,]))
}
save_deg <- function(df, sub, dir) {
  rel <- df[df$padj<PADJ_CUT & !is.na(df$padj), ]
  str <- rel[abs(rel$log2FoldChange)>LFC_CUT, ]
  rel <- rel[order(rel$padj), ]; str <- str[order(str$padj), ]
  write.csv(df,  file.path(dir, sprintf("DEG_%s_ALL.csv", sub)),     row.names=FALSE)
  write.csv(rel, file.path(dir, sprintf("DEG_%s_RELAXED.csv", sub)), row.names=FALSE)
  write.csv(str, file.path(dir, sprintf("DEG_%s_STRICT.csv", sub)),  row.names=FALSE)
}

## ---- 5. 三个 pairwise Wald 对比 ---------------------------------------------
res_5v0  <- results(dds, name="timepoint_5_vs_0",  alpha=PADJ_CUT)
res_15v0 <- results(dds, name="timepoint_15_vs_0", alpha=PADJ_CUT)
res_15v5 <- results(dds, contrast=c("timepoint","15","5"), alpha=PADJ_CUT)

df_5v0  <- annotate_res(res_5v0)
df_15v0 <- annotate_res(res_15v0)
df_15v5 <- annotate_res(res_15v5)

cat("\n========== DEG 计数（全分解，live） ==========")
report_counts(df_5v0,  "5min vs 0min")
report_counts(df_15v0, "15min vs 0min")
report_counts(df_15v5, "15min vs 5min")

## ---- 6. LRT（随时间变化基因集；只看 padj，LFC 列无意义） ---------------------
dds_lrt <- DESeq(dds, test="LRT", reduced = ~ replicate)
res_lrt <- results(dds_lrt)              # padj = 任意 timepoint 效应
df_lrt  <- annotate_res(res_lrt)
n_lrt   <- sum(df_lrt$padj < PADJ_CUT & !is.na(df_lrt$padj))
cat(sprintf("\n────────── LRT (full ~replicate+timepoint vs reduced ~replicate) ──────────\n"))
cat(sprintf("  随时间变化基因 (padj<%.2f) : %d   (NA padj: %d)\n",
            PADJ_CUT, n_lrt, sum(is.na(df_lrt$padj))))
cat("  注：LRT 无方向，LFC 列不作效应量解读。\n")

## ---- 7. 导出 + 存对象 -------------------------------------------------------
save_deg(df_5v0,  "5v0",  deg_dir)
save_deg(df_15v0, "15v0", deg_dir)
save_deg(df_15v5, "15v5", deg_dir)
write.csv(df_lrt[order(df_lrt$padj), ], file.path(deg_dir,"DEG_LRT_ALL.csv"), row.names=FALSE)

saveRDS(dds,      file.path(obj_dir,"dds_fitted.rds"))      # Wald 拟合（含三 pairwise）
saveRDS(dds_lrt,  file.path(obj_dir,"dds_lrt.rds"))
saveRDS(list(res_5v0=res_5v0, res_15v0=res_15v0, res_15v5=res_15v5, res_lrt=res_lrt),
        file.path(obj_dir,"res_all.rds"))
saveRDS(list(df_5v0=df_5v0, df_15v0=df_15v0, df_15v5=df_15v5, df_lrt=df_lrt),
        file.path(obj_dir,"deg_tables.rds"))

cat("\n[saved] DEG csv -> results/03_DEG/ ; objects -> results/objects/\n")
cat("下一步：核对上面计数 + 方向校验，再进 Phase 4（火山/热图/轨迹）。\n")
writeLines(capture.output(sessionInfo()), file.path(obj_dir,"sessionInfo_03.txt"))
