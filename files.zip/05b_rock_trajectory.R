## ============================================================================
## acute Netrin-1 RNA-seq  ·  05b_rock_trajectory.R   (Phase 4 · ROCK 对比轨迹)
## ----------------------------------------------------------------------------
## Rock1 vs Rock2 时序轨迹对比：展示 Netrin 急性下调为 Rock1 特异、Rock2 不动。
## 纵轴 = fold-change vs Vehicle（各除自身 Vehicle 均值）；均值线+SEM 带 + 每重复点。
## 副标题用 sprintf 放两者 5v0 padj（数据驱动）。读现成对象，先预览后存。
## ============================================================================
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"
obj_dir  <- file.path(out_base, "results/objects")
fig_dir  <- file.path(out_base, "results/03_DEG")

suppressPackageStartupMessages({ library(DESeq2); library(ggplot2); library(dplyr) })

dds  <- readRDS(file.path(obj_dir, "dds_fitted.rds"))
res  <- readRDS(file.path(obj_dir, "res_all.rds"))
anno <- read.csv(file.path(obj_dir, "gene_annotation.csv"), stringsAsFactors=FALSE)
rownames(anno) <- anno$ensembl

genes <- c("Rock1","Rock2")
ens   <- setNames(anno$ensembl[match(genes, anno$symbol)], genes)
stopifnot(all(!is.na(ens)))

p_rock1 <- res$res_5v0[ens["Rock1"], "padj"]
p_rock2 <- res$res_5v0[ens["Rock2"], "padj"]

nc  <- counts(dds, normalized=TRUE)
grp <- as.character(colData(dds)$timepoint)
rep <- as.character(colData(dds)$replicate)

tp_levels <- c("0","5","15"); tp_labels <- c("Vehicle","5 min","15 min")
sem <- function(x) sd(x)/sqrt(length(x))

pts <- list(); summ <- list()
for (g in genes) {
  v    <- nc[ens[g], ]
  base <- mean(v[grp=="0"])
  fc   <- v / base
  for (i in seq_along(fc)) {
    pts[[length(pts)+1]] <- data.frame(gene=g, timepoint=grp[i], rep=rep[i], fc=fc[i])
  }
  for (tp in tp_levels) {
    x <- fc[grp==tp]
    summ[[length(summ)+1]] <- data.frame(gene=g, timepoint=tp, mean=mean(x), sem=sem(x))
  }
}
pts  <- do.call(rbind, pts);  summ <- do.call(rbind, summ)
lab <- function(d){ d$timepoint <- factor(d$timepoint, levels=tp_levels, labels=tp_labels); d }
pts <- lab(pts); summ <- lab(summ)
pts$gene  <- factor(pts$gene,  levels=genes); summ$gene <- factor(summ$gene, levels=genes)

gene_col <- c(Rock1="#3B7AB8", Rock2="#999999")

cat(sprintf("Rock1 5v0 padj = %.2g ; Rock2 5v0 padj = %.2g\n", p_rock1, p_rock2))
for (g in genes) {
  s <- summ[summ$gene==g, ]
  cat(sprintf("%-6s: %.2f -> %.2f -> %.2f\n", g, s$mean[1], s$mean[2], s$mean[3]))
}

sub <- sprintf("Fold-change vs Vehicle (mean \u00B1 SEM, n=3). 5 min vs Vehicle padj: Rock1 %.1e (sig) | Rock2 %.2f (n.s.)",
               p_rock1, p_rock2)

p <- ggplot(summ, aes(timepoint, mean, color=gene, group=gene)) +
  geom_hline(yintercept=1, linetype="dashed", color="grey60", linewidth=0.4) +
  geom_ribbon(aes(ymin=mean-sem, ymax=mean+sem, fill=gene), alpha=0.15, color=NA, show.legend=FALSE) +
  geom_jitter(data=pts, aes(timepoint, fc, color=gene), width=0.04, size=1.6, alpha=0.55, show.legend=FALSE) +
  geom_line(linewidth=1.1) +
  geom_point(size=3) +
  scale_color_manual(values=gene_col, name="Gene") +
  scale_fill_manual(values=gene_col) +
  labs(title="ROCK1 vs ROCK2: acute time-course (Netrin-1)",
       subtitle=sub, x=NULL, y="Fold-change vs Vehicle") +
  theme_bw(base_size=12) +
  theme(panel.grid.minor=element_blank(),
        plot.title=element_text(size=14, face="bold"),
        plot.subtitle=element_text(size=9, color="grey40"),
        legend.position="right")

print(p)
ggsave(file.path(fig_dir,"05b_rock1_vs_rock2_trajectory.pdf"), p, width=8, height=5.5)
ggsave(file.path(fig_dir,"05b_rock1_vs_rock2_trajectory.png"), p, width=8, height=5.5, dpi=300)
cat("\n[fig] 05b_rock1_vs_rock2_trajectory saved\n")
