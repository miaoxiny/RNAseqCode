## ============================================================================
## acute Netrin-1 RNA-seq  ·  07_celltype_composition.R   (Phase 2 · 细胞组成核查)
## 22 marker × 7 类，每条件 mean TPM+1，log10 轴，facet 分类，绿梯度三色。
## 数据源 tpm_matrix_raw.rds（00_export_tpm.R 生成，32623 全基因）。
## 结论：神经元为主、三条件组成一致 → DEG 是真转录响应非组成漂移。
## 注：P2ry12 在 gene_annotation 无映射，已剔除（Microglia 用 Aif1+Tmem119）。
## ============================================================================
out_base <- "D:/Dropbox/Dropbox/RNAseq 2025/Time analysis"
obj_dir  <- file.path(out_base, "results/objects")
fig_dir  <- file.path(out_base, "results/02_composition")
dir.create(fig_dir, recursive=TRUE, showWarnings=FALSE)
suppressPackageStartupMessages({ library(ggplot2); library(dplyr) })

tpm     <- readRDS(file.path(obj_dir, "tpm_matrix_raw.rds"))
samples <- readRDS(file.path(obj_dir, "sample_sheet.rds"))
anno    <- read.csv(file.path(obj_dir, "gene_annotation.csv"), stringsAsFactors=FALSE)
sym2ens <- setNames(anno$ensembl, anno$symbol)

panel <- list(
  "Pan-neuronal"      = c("Tubb3","Stmn2","Map2","Snap25"),
  "Cortical neuron"   = c("Foxg1","Satb2","Neurod2","Tbr1"),
  "Neural progenitor" = c("Nes","Pax6","Hes5"),
  "Astrocyte"         = c("Aldh1l1","Gfap","Slc1a3"),
  "Oligodendrocyte"   = c("Pdgfra","Sox10","Olig2"),
  "Microglia"         = c("Aif1","Tmem119"),
  "Endothelial"       = c("Eng","Flt1","Vwf"))

grp <- as.character(samples[colnames(tpm), "timepoint"])
cond_levels <- c("0","5","15"); cond_labels <- c("Vehicle","5min Netrin-1","15min Netrin-1")

rows <- list()
for (ct in names(panel)) for (m in panel[[ct]]) {
  e <- sym2ens[m]; if (is.na(e) || !e %in% rownames(tpm)) next
  v <- tpm[e, ]
  for (i in seq_along(cond_levels)) {
    tp <- cond_levels[i]
    rows[[length(rows)+1]] <- data.frame(celltype=ct, marker=m,
      condition=cond_labels[i], meanTPM=mean(v[grp==tp])+1)
  }
}
df <- do.call(rbind, rows)
df$celltype  <- factor(df$celltype, levels=names(panel))
df$condition <- factor(df$condition, levels=cond_labels)
df$marker    <- factor(df$marker, levels=rev(unlist(panel, use.names=FALSE)))
cond_col <- setNames(c("#E1EAD7","#6B9A5C","#264020"), cond_labels)

p <- ggplot(df, aes(meanTPM, marker, fill=condition)) +
  geom_point(size=4, shape=21, stroke=0.3, color="grey30") +
  scale_x_log10(limits=c(1,1e4), breaks=c(1,10,100,1000,10000),
                labels=c("1","10","100","1000","10000")) +
  scale_fill_manual(values=cond_col, name=NULL) +
  facet_grid(celltype ~ ., scales="free_y", space="free_y", switch="y") +
  labs(title="Cell-type marker expression",
       subtitle="Mean TPM + 1 per condition (log10 axis). Bulk expression, not cell proportions.",
       x="Mean TPM + 1", y=NULL) +
  theme_bw(base_size=12) +
  theme(strip.placement="outside",
        strip.text.y.left=element_text(angle=0, face="bold", size=10),
        strip.background=element_rect(fill="grey90", color="grey50"),
        panel.grid.minor=element_blank(), legend.position="bottom",
        plot.title=element_text(size=14, face="bold"),
        plot.subtitle=element_text(size=10, color="grey40"))

ggsave(file.path(fig_dir,"07_celltype_marker_TPM.pdf"), p, width=9, height=9)
ggsave(file.path(fig_dir,"07_celltype_marker_TPM.png"), p, width=9, height=9, dpi=300)
cat("[fig] 07_celltype_marker_TPM saved\n")
